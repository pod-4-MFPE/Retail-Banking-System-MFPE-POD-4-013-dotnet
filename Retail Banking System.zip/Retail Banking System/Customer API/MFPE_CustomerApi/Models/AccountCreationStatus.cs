﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MFPE_CustomerApi.Models
{
    public class AccountCreationStatus
    { 
        public string Message { get; set; }
        public int AccountId { get; set; }
    }
}

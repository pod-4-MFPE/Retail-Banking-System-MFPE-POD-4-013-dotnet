﻿using Castle.Components.DictionaryAdapter;
using System;
using System.Collections.Generic;
using System.Text;

namespace AccountTests
{
   public class StatementViewModel1
    {
       
        public int AccountId { get; set; }
        public DateTime from_date { get; set; }
        public DateTime to_date { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AccountTests
{
  public  class AccountViewModel1
    {
        public int AccountId { get; set; }
        public int amount { get; set; }
    }
}

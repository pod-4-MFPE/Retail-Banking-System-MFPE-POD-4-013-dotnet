﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Account_Microservice.Models.ViewModel
{
	public class AccountViewModel
	{
		public int Id { get; set; }
		public double Balance { get; set; }
	}
}

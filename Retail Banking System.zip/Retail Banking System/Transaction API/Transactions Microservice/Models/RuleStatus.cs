﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Transactions_Microservice.Models
{
    public class RuleStatus
    {
     public string Status { get; set; }
    }
}

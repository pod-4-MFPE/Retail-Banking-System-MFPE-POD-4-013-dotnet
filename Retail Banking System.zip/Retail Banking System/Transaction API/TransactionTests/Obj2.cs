﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TransactionTests
{
    public class Obj2
    {
        public int Source_AccountId { get; set; }
        public int Target_AccountId { get; set; }
        public int amount { get; set; }
    }
}

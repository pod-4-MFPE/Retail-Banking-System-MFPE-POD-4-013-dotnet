﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TransactionTests
{
    public class Obj
    {
        public int AccountId { get; set; }
        public int amount { get; set; }
    }
}

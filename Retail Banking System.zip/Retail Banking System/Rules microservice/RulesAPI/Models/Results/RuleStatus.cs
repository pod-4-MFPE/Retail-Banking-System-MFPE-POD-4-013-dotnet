﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RulesAPI.Models
{
    public class RuleStatus
    {
        public string Status { get; set; }
    }
}
